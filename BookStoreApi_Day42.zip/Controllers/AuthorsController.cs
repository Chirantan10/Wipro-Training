using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BookStoreApi.Models;

namespace BookStoreApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthorsController : ControllerBase
    {
        private readonly BookStoreContext _db;
        public AuthorsController(BookStoreContext db) => _db = db;

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var authors = await _db.Authors.Include(a => a.Books).ToListAsync();
            return Ok(authors);
        }

        [HttpGet("{id}", Name = "GetAuthorById")]
        public async Task<IActionResult> GetById(int id)
        {
            var author = await _db.Authors.Include(a => a.Books).FirstOrDefaultAsync(a => a.Id == id);
            if (author == null) return NotFound(new { Message = "Author not found" });
            return Ok(author);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Author author)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);
            _db.Authors.Add(author);
            await _db.SaveChangesAsync();
            return CreatedAtRoute("GetAuthorById", new { id = author.Id }, author);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] Author updated)
        {
            if (id != updated.Id) return BadRequest(new { Message = "Id mismatch" });
            var author = await _db.Authors.FindAsync(id);
            if (author == null) return NotFound();
            author.Name = updated.Name;
            author.Bio = updated.Bio;
            await _db.SaveChangesAsync();
            return Ok(author);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var author = await _db.Authors.FindAsync(id);
            if (author == null) return NotFound();
            _db.Authors.Remove(author);
            await _db.SaveChangesAsync();
            return NoContent();
        }

        // GET api/authors/{id}/books
        [HttpGet("{id}/books")]
        public async Task<IActionResult> GetBooksByAuthor(int id)
        {
            var author = await _db.Authors.Include(a => a.Books).FirstOrDefaultAsync(a => a.Id == id);
            if (author == null) return NotFound(new { Message = "Author not found" });
            return Ok(author.Books);
        }
    }
}
