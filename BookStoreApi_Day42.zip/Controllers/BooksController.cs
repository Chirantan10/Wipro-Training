using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BookStoreApi.Models;

namespace BookStoreApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BooksController : ControllerBase
    {
        private readonly BookStoreContext _db;
        public BooksController(BookStoreContext db) => _db = db;

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var books = await _db.Books.Include(b => b.Author).ToListAsync();
            return Ok(books);
        }

        [HttpGet("{id}", Name = "GetBookById")]
        public async Task<IActionResult> GetById(int id)
        {
            var book = await _db.Books.Include(b => b.Author).FirstOrDefaultAsync(b => b.Id == id);
            if (book == null) return NotFound(new { Message = "Book not found" });
            return Ok(book);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Book book)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var author = await _db.Authors.FindAsync(book.AuthorId);
            if (author == null) return BadRequest(new { Message = $"Author with id {book.AuthorId} does not exist" });

            _db.Books.Add(book);
            await _db.SaveChangesAsync();
            return CreatedAtRoute("GetBookById", new { id = book.Id }, book);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] Book updated)
        {
            if (id != updated.Id) return BadRequest(new { Message = "Id mismatch" });
            var book = await _db.Books.FindAsync(id);
            if (book == null) return NotFound();
            var author = await _db.Authors.FindAsync(updated.AuthorId);
            if (author == null) return BadRequest(new { Message = $"Author with id {updated.AuthorId} does not exist" });

            book.Title = updated.Title;
            book.PublicationYear = updated.PublicationYear;
            book.AuthorId = updated.AuthorId;

            await _db.SaveChangesAsync();
            return Ok(book);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var book = await _db.Books.FindAsync(id);
            if (book == null) return NotFound();
            _db.Books.Remove(book);
            await _db.SaveChangesAsync();
            return NoContent();
        }
    }
}
