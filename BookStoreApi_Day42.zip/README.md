# BookStoreApi

This is a simple ASP.NET Core Web API implementing a RESTful backend for an online book store.
It supports CRUD operations for **Authors** and **Books**, including associations (one author -> many books).
Routing uses attribute routing and there is an endpoint to fetch all books by a specific author:
`GET /api/authors/{authorId}/books`.

## Features
- ASP.NET Core Web API (Controllers + attribute routing)
- EF Core with SQLite (lightweight DB)
- Validation using data annotations
- Proper RESTful status codes: 200, 201, 204, 400, 404
- Swagger UI for interactive testing
- Postman collection included for quick testing
- Guidance for using Fiddler to inspect traffic

## Prerequisites
- .NET SDK 7.0 or newer: https://dotnet.microsoft.com/en-us/download
- Postman (for API testing) — optional
- Fiddler (for HTTP inspection) — optional

## Running locally
1. Open a terminal and navigate to the project folder:
   ```
   cd BookStoreApi
   ```
2. Restore packages and run:
   ```
   dotnet restore
   dotnet run
   ```
   By default the app will create `bookstore.db` in the project folder and run on the default Kestrel URLs.

3. Open Swagger UI (if running in Development):
   - `https://localhost:5001/swagger` (or the URL shown in the console)

## API Endpoints (overview)
- `GET /api/books` - list all books (includes author)
- `GET /api/books/{id}` - get book by id
- `POST /api/books` - create a book (`Title`, `PublicationYear`, `AuthorId`)
- `PUT /api/books/{id}` - update a book
- `DELETE /api/books/{id}` - delete a book

- `GET /api/authors` - list all authors (includes books)
- `GET /api/authors/{id}` - get author by id
- `POST /api/authors` - create an author (`Name`, `Bio`)
- `PUT /api/authors/{id}` - update an author
- `DELETE /api/authors/{id}` - delete an author

- `GET /api/authors/{authorId}/books` - get all books by an author

## Testing with Postman
1. Import the included `postman_collection.json` into Postman.
2. Set an environment variable `base_url` to `https://localhost:5001` (or the URL from `dotnet run`).
3. Run the requests in the collection. Example POST body for creating an author:
```json
{
  "name": "New Author",
  "bio": "Short bio"
}
```
POST body for creating a book:
```json
{
  "title": "New Book",
  "publicationYear": 2024,
  "authorId": 1
}
```

Expected status codes:
- `GET` -> 200 OK
- `POST` -> 201 Created
- `PUT` -> 200 OK
- `DELETE` -> 204 No Content
- Bad or missing data -> 400 Bad Request
- Not found -> 404 Not Found

## Inspecting traffic with Fiddler
1. Start Fiddler (it will capture HTTP/HTTPS).
2. Configure Postman to use Fiddler as proxy (Fiddler defaults to 127.0.0.1:8888).
3. Make requests from Postman and inspect them in Fiddler for headers, body, status codes.
4. Verify `Content-Type: application/json` and expected response codes.

## Notes & Extensions
- You can swap SQLite for InMemory or SQL Server by changing the `UseSqlite` call in `Program.cs`.
- Add DTOs/AutoMapper for cleaner separation between persistence models and API contracts.
- Add authentication/authorization if needed.

