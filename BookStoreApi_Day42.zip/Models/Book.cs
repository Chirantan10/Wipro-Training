using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BookStoreApi.Models
{
    public class Book
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string Title { get; set; } = null!;

        [Range(0, 2100)]
        public int PublicationYear { get; set; }

        [Required]
        public int AuthorId { get; set; }

        public Author? Author { get; set; }
    }
}
