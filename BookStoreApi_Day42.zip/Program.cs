using Microsoft.EntityFrameworkCore;
using BookStoreApi.Models;

var builder = WebApplication.CreateBuilder(args);

// Add services
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddDbContext<BookStoreContext>(options =>
    options.UseSqlite(builder.Configuration.GetConnectionString("DefaultConnection") ??
                      "Data Source=bookstore.db"));

var app = builder.Build();

// Seed sample data
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<BookStoreContext>();
    db.Database.EnsureCreated();

    if (!db.Authors.Any())
    {
        var author1 = new Author { Name = "Jane Austen", Bio = "English novelist" };
        var author2 = new Author { Name = "George Orwell", Bio = "English novelist and essayist" };
        db.Authors.AddRange(author1, author2);

        db.Books.AddRange(
            new Book { Title = "Pride and Prejudice", PublicationYear = 1813, Author = author1 },
            new Book { Title = "1984", PublicationYear = 1949, Author = author2 }
        );

        db.SaveChanges();
    }
}

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();
app.Run();
