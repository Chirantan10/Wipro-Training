using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace SecureAuthSolution.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class ProtectedController : ControllerBase
    {
        [HttpGet("user-data")]
        public IActionResult GetUserData()
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            var userEmail = User.FindFirst(ClaimTypes.Email)?.Value;
            
            return Ok(new { 
                Message = "This is protected user data",
                UserId = userId,
                Email = userEmail,
                AccessedAt = DateTime.UtcNow
            });
        }

        [HttpGet("admin-data")]
        [Authorize(Roles = "Admin")]
        public IActionResult GetAdminData()
        {
            return Ok(new { 
                Message = "This is admin-only data",
                AccessedAt = DateTime.UtcNow
            });
        }

        [HttpGet("user-or-admin")]
        [Authorize(Roles = "Admin,User")]
        public IActionResult GetUserOrAdminData()
        {
            return Ok(new { 
                Message = "This data is accessible to both users and admins",
                AccessedAt = DateTime.UtcNow
            });
        }
    }
}