# Movie Catalog API (ASP.NET Core)

This is a sample RESTful Web API built with ASP.NET Core that allows CRUD operations on Movies and Directors.
It implements:
- RESTful routes with attribute routing
- Associations between Movies and Directors
- Validation using DataAnnotations
- SQLite database (created automatically)
- Swagger for quick manual testing

## Quick start

**Prerequisites**
- .NET SDK 7.0+ (download from https://dotnet.microsoft.com)
- (optional) Postman and Fiddler for testing

**Run the API**
1. Unzip the project and `cd` into `MovieCatalogApi` folder.
2. Restore packages and run:
```bash
dotnet restore
dotnet run
```
3. By default the API will use the `MovieCatalog.db` SQLite file created at runtime.
4. Open Swagger UI during development at `https://localhost:{port}/swagger` (port shown in console).

## API endpoints (examples)
- `GET /api/movies` - list all movies
- `GET /api/movies/{id}` - get movie by id
- `POST /api/movies` - create a movie (JSON body)
- `PUT /api/movies/{id}` - update movie
- `DELETE /api/movies/{id}` - delete movie
- `GET /api/directors` - list all directors
- `GET /api/directors/{id}` - get director by id
- `GET /api/directors/{id}/movies` - get movies by director
- `POST /api/directors` - create a director
- `PUT /api/directors/{id}` - update director
- `DELETE /api/directors/{id}` - delete director (only allowed if director has no movies)

## Request examples

Create a director:
```json
POST /api/directors
{
  "name": "New Director"
}
```

Create a movie (use existing director id):
```json
POST /api/movies
{
  "title": "My Movie",
  "releaseYear": 2024,
  "directorId": 1
}
```

Or create a movie and a new director in one request:
```json
POST /api/movies
{
  "title": "Another Movie",
  "releaseYear": 2023,
  "directorName": "Someone New"
}
```

## Testing with Postman and Fiddler

- Import the included `postman_collection.json` into Postman (File -> Import).
- Use environment variable `baseUrl` set to `http://localhost:5000` or your actual application URL/port.
- Use Fiddler to inspect requests: start Fiddler, then send requests from Postman; Fiddler will capture and display HTTP requests/responses. Verify method, headers (Content-Type: application/json), status codes, and response body.

## Notes & validation
- Basic validation is implemented via attributes like `[Required]` and `[Range]`.
- Endpoints return proper HTTP status codes: `200 OK`, `201 Created`, `204 No Content`, `400 Bad Request`, `404 Not Found`.
- For production use you may want to add authentication, paging, logging, and more robust error handling.
