using System.ComponentModel.DataAnnotations;

namespace MovieCatalogApi.DTOs
{
    public class MovieCreateDto
    {
        [Required]
        public string Title { get; set; } = string.Empty;

        [Range(1888, 2100)]
        public int ReleaseYear { get; set; }

        // Either provide DirectorId (to use existing director) or DirectorName (to create a new one)
        public int? DirectorId { get; set; }
        public string? DirectorName { get; set; }
    }
}
