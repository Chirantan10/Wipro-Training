using System.ComponentModel.DataAnnotations;

namespace MovieCatalogApi.DTOs
{
    public class MovieUpdateDto
    {
        [Required]
        public string Title { get; set; } = string.Empty;

        [Range(1888, 2100)]
        public int ReleaseYear { get; set; }

        public int DirectorId { get; set; }
    }
}
