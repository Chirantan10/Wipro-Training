using System.ComponentModel.DataAnnotations;

namespace MovieCatalogApi.DTOs
{
    public class DirectorCreateDto
    {
        [Required]
        public string Name { get; set; } = string.Empty;
    }
}
