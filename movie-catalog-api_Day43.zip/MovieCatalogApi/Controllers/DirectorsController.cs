using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MovieCatalogApi.Data;
using MovieCatalogApi.DTOs;
using MovieCatalogApi.Models;

namespace MovieCatalogApi.Controllers
{
    [ApiController]
    [Route("api/directors")]
    public class DirectorsController : ControllerBase
    {
        private readonly AppDbContext _db;

        public DirectorsController(AppDbContext db)
        {
            _db = db;
        }

        // GET: api/directors
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var directors = await _db.Directors.ToListAsync();
            return Ok(directors);
        }

        // GET: api/directors/{id}
        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetById(int id)
        {
            var director = await _db.Directors.FindAsync(id);
            if (director == null) return NotFound(new { Message = $"Director with id {id} not found." });
            return Ok(director);
        }

        // GET: api/directors/{id}/movies
        [HttpGet("{id:int}/movies")]
        public async Task<IActionResult> GetMoviesByDirector(int id)
        {
            var director = await _db.Directors.FindAsync(id);
            if (director == null) return NotFound(new { Message = $"Director with id {id} not found." });

            var movies = await _db.Movies.Where(m => m.DirectorId == id).ToListAsync();
            return Ok(movies);
        }

        // POST: api/directors
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] DirectorCreateDto dto)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var director = new Director { Name = dto.Name.Trim() };
            _db.Directors.Add(director);
            await _db.SaveChangesAsync();

            return CreatedAtAction(nameof(GetById), new { id = director.Id }, director);
        }

        // PUT: api/directors/{id}
        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update(int id, [FromBody] DirectorCreateDto dto)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var director = await _db.Directors.FindAsync(id);
            if (director == null) return NotFound(new { Message = $"Director with id {id} not found." });

            director.Name = dto.Name.Trim();
            await _db.SaveChangesAsync();
            return NoContent();
        }

        // DELETE: api/directors/{id}
        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var director = await _db.Directors.Include(d => d.Movies).FirstOrDefaultAsync(d => d.Id == id);
            if (director == null) return NotFound(new { Message = $"Director with id {id} not found." });

            if (director.Movies.Any())
            {
                // Prevent accidental delete of a director who still has movies
                return BadRequest(new { Message = "Cannot delete director who has movies. Delete related movies first." });
            }

            _db.Directors.Remove(director);
            await _db.SaveChangesAsync();
            return NoContent();
        }
    }
}
