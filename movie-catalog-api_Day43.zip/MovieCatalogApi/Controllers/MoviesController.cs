using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MovieCatalogApi.Data;
using MovieCatalogApi.DTOs;
using MovieCatalogApi.Models;

namespace MovieCatalogApi.Controllers
{
    [ApiController]
    [Route("api/movies")]
    public class MoviesController : ControllerBase
    {
        private readonly AppDbContext _db;

        public MoviesController(AppDbContext db)
        {
            _db = db;
        }

        // GET: api/movies
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var movies = await _db.Movies.Include(m => m.Director).ToListAsync();
            return Ok(movies);
        }

        // GET: api/movies/{id}
        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetById(int id)
        {
            var movie = await _db.Movies.Include(m => m.Director).FirstOrDefaultAsync(m => m.Id == id);
            if (movie == null) return NotFound(new { Message = $"Movie with id {id} not found." });
            return Ok(movie);
        }

        // POST: api/movies
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] MovieCreateDto dto)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            Director? director = null;
            if (dto.DirectorId.HasValue)
            {
                director = await _db.Directors.FindAsync(dto.DirectorId.Value);
                if (director == null) return BadRequest(new { Message = $"Director with id {dto.DirectorId.Value} not found." });
            }
            else if (!string.IsNullOrWhiteSpace(dto.DirectorName))
            {
                director = new Director { Name = dto.DirectorName.Trim() };
                _db.Directors.Add(director);
                await _db.SaveChangesAsync();
            }
            else
            {
                return BadRequest(new { Message = "Either DirectorId or DirectorName must be provided." });
            }

            var movie = new Movie
            {
                Title = dto.Title.Trim(),
                ReleaseYear = dto.ReleaseYear,
                DirectorId = director!.Id
            };

            _db.Movies.Add(movie);
            await _db.SaveChangesAsync();

            return CreatedAtAction(nameof(GetById), new { id = movie.Id }, movie);
        }

        // PUT: api/movies/{id}
        [HttpPut("{id:int}")]
        public async Task<IActionResult> Update(int id, [FromBody] MovieUpdateDto dto)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var movie = await _db.Movies.FindAsync(id);
            if (movie == null) return NotFound(new { Message = $"Movie with id {id} not found." });

            var director = await _db.Directors.FindAsync(dto.DirectorId);
            if (director == null) return BadRequest(new { Message = $"Director with id {dto.DirectorId} not found." });

            movie.Title = dto.Title.Trim();
            movie.ReleaseYear = dto.ReleaseYear;
            movie.DirectorId = dto.DirectorId;

            await _db.SaveChangesAsync();
            return NoContent();
        }

        // DELETE: api/movies/{id}
        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            var movie = await _db.Movies.FindAsync(id);
            if (movie == null) return NotFound(new { Message = $"Movie with id {id} not found." });

            _db.Movies.Remove(movie);
            await _db.SaveChangesAsync();
            return NoContent();
        }
    }
}
