using System.ComponentModel.DataAnnotations;

namespace MovieCatalogApi.Models
{
    public class Movie
    {
        public int Id { get; set; }

        [Required]
        public string Title { get; set; } = string.Empty;

        [Range(1888, 2100)]
        public int ReleaseYear { get; set; }

        // foreign key
        public int DirectorId { get; set; }
        public Director? Director { get; set; }
    }
}
