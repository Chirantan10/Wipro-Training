using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace MovieCatalogApi.Models
{
    public class Director
    {
        public int Id { get; set; }

        [Required]
        public string Name { get; set; } = string.Empty;

        [JsonIgnore]
        public ICollection<Movie> Movies { get; set; } = new List<Movie>();
    }
}
