using MovieCatalogApi.Models;

namespace MovieCatalogApi.Data
{
    public static class SeedData
    {
        public static void Initialize(AppDbContext context)
        {
            if (context.Directors.Any() || context.Movies.Any())
                return;

            var d1 = new Director { Name = "Christopher Nolan" };
            var d2 = new Director { Name = "Greta Gerwig" };

            context.Directors.AddRange(d1, d2);
            context.SaveChanges();

            context.Movies.AddRange(
                new Movie { Title = "Inception", ReleaseYear = 2010, DirectorId = d1.Id },
                new Movie { Title = "Interstellar", ReleaseYear = 2014, DirectorId = d1.Id },
                new Movie { Title = "Little Women", ReleaseYear = 2019, DirectorId = d2.Id }
            );

            context.SaveChanges();
        }
    }
}
