using System.Security.Cryptography;
using System.Text;

namespace DatabaseSecuritySolution.Utilities
{
    public static class EncryptionUtility
    {
        public static string GenerateHMAC(string data, string key)
        {
            using (HMACSHA256 hmac = new HMACSHA256(Encoding.UTF8.GetBytes(key)))
            {
                byte[] hash = hmac.ComputeHash(Encoding.UTF8.GetBytes(data));
                return Convert.ToBase64String(hash);
            }
        }

        public static bool VerifyHMAC(string data, string key, string hash)
        {
            string computedHash = GenerateHMAC(data, key);
            return computedHash == hash;
        }

        public static string GenerateSecureRandomString(int length)
        {
            const string validChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            using (RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider())
            {
                byte[] uintBuffer = new byte[sizeof(uint)];
                StringBuilder result = new StringBuilder(length);
                
                while (length-- > 0)
                {
                    rng.GetBytes(uintBuffer);
                    uint num = BitConverter.ToUInt32(uintBuffer, 0);
                    result.Append(validChars[(int)(num % (uint)validChars.Length)]);
                }
                
                return result.ToString();
            }
        }
    }
}