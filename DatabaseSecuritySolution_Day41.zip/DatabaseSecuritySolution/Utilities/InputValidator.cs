using System.Text.RegularExpressions;

namespace DatabaseSecuritySolution.Utilities
{
    public static class InputValidator
    {
        public static bool IsValidEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email)) return false;
            
            try
            {
                // Simple regex for basic email validation
                return Regex.IsMatch(email, 
                    @"^[^@s]+@[^@s]+.[^@s]+$", 
                    RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(250));
            }
            catch (RegexMatchTimeoutException)
            {
                return false;
            }
        }

        public static bool IsValidCreditCard(string cardNumber)
        {
            if (string.IsNullOrWhiteSpace(cardNumber)) return false;
            
            // Remove any non-digit characters
            cardNumber = Regex.Replace(cardNumber, @"[^d]", "");
            
            // Check length and Luhn algorithm
            if (cardNumber.Length < 13 || cardNumber.Length > 19) return false;
            
            return IsLuhnValid(cardNumber);
        }

        private static bool IsLuhnValid(string cardNumber)
        {
            int sum = 0;
            bool alternate = false;
            
            for (int i = cardNumber.Length - 1; i >= 0; i--)
            {
                int digit = int.Parse(cardNumber[i].ToString());
                
                if (alternate)
                {
                    digit *= 2;
                    if (digit > 9) digit -= 9;
                }
                
                sum += digit;
                alternate = !alternate;
            }
            
            return (sum % 10 == 0);
        }

        public static string SanitizeInput(string input)
        {
            if (string.IsNullOrEmpty(input)) return input;
            
            // Remove potentially dangerous characters
            return Regex.Replace(input, @"[<>""'&]", string.Empty);
        }

        public static bool ContainsSqlInjectionPattern(string input)
        {
            if (string.IsNullOrEmpty(input)) return false;
            
            // Common SQL injection patterns
            var patterns = new string[]
            {
                @"((SELECT|INSERT|UPDATE|DELETE|DROP|UNION|EXEC|ALTER|CREATE|TRUNCATE))",
                @"(--|/*|*/|;)",
                @"((OR|AND)s+d+s*=s*d+)",
                @"((WAITFOR|DELAY)s+')"
            };
            
            foreach (var pattern in patterns)
            {
                if (Regex.IsMatch(input, pattern, RegexOptions.IgnoreCase))
                    return true;
            }
            
            return false;
        }
    }
}