using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using DatabaseSecuritySolution.Services;
using System.ComponentModel.DataAnnotations;

namespace DatabaseSecuritySolution.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class SecureDataController : ControllerBase
    {
        private readonly SecureDatabaseService _dbService;
        private readonly DatabaseEncryptionService _encryptionService;

        public SecureDataController(
            SecureDatabaseService dbService, 
            DatabaseEncryptionService encryptionService)
        {
            _dbService = dbService;
            _encryptionService = encryptionService;
        }

        [HttpGet("user/{id}")]
        public IActionResult GetUserData(int id)
        {
            // Input validation
            if (id <= 0) return BadRequest("Invalid user ID");

            var userData = _dbService.GetUserById(id);
            if (userData == null) return NotFound();

            return Ok(userData);
        }

        [HttpPost("encrypt")]
        public IActionResult EncryptData([FromBody] string data)
        {
            // Input validation
            if (string.IsNullOrEmpty(data)) 
                return BadRequest("Data cannot be empty");

            try
            {
                var encryptedData = _encryptionService.EncryptData(data);
                return Ok(new { encryptedData });
            }
            catch (Exception ex)
            {
                // Log error without exposing sensitive information
                return StatusCode(500, "An error occurred during encryption");
            }
        }

        [HttpPost("user")]
        [Authorize(Roles = "Admin")]
        public IActionResult CreateUser([FromBody] User user)
        {
            // Input validation using data annotations
            if (!ModelState.IsValid) return BadRequest(ModelState);

            try
            {
                var result = _dbService.CreateUser(user);
                return CreatedAtAction(nameof(GetUserData), new { id = result.Id }, result);
            }
            catch (Exception ex)
            {
                // Log error
                return StatusCode(500, "An error occurred while creating user");
            }
        }
    }

    public class User
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Name { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        [CreditCard]
        public string CreditCardNumber { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}