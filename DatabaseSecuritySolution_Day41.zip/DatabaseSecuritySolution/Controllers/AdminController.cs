using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using DatabaseSecuritySolution.Services;

namespace DatabaseSecuritySolution.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "Admin")]
    public class AdminController : ControllerBase
    {
        private readonly SecurityAssessmentService _securityService;

        public AdminController(SecurityAssessmentService securityService)
        {
            _securityService = securityService;
        }

        [HttpGet("security-assessment")]
        public IActionResult GetSecurityAssessment()
        {
            var assessment = _securityService.RunSecurityAssessment();
            return Ok(assessment);
        }

        [HttpPost("pen-test")]
        public IActionResult RunPenetrationTest()
        {
            var results = _securityService.RunPenetrationTest();
            return Ok(results);
        }

        [HttpGet("audit-logs")]
        public IActionResult GetAuditLogs()
        {
            var logs = _securityService.GetAuditLogs();
            return Ok(logs);
        }
    }
}