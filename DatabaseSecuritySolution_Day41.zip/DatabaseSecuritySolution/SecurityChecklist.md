# Database Security Checklist

## Encryption
- [ ] Enable TDE on database
- [ ] Implement column-level encryption for sensitive data
- [ ] Use SSL/TLS for all database connections
- [ ] Secure encryption key storage (Azure Key Vault/AWS Secrets Manager)

## Secure Coding
- [ ] Use parameterized queries exclusively
- [ ] Validate all user inputs
- [ ] Implement output encoding
- [ ] Use ORM with built-in protection

## Access Control
- [ ] Implement least privilege access
- [ ] Set up RBAC roles
- [ ] Secure database credentials
- [ ] Enable database auditing

## Security Testing
- [ ] Conduct regular security assessments
- [ ] Perform penetration testing
- [ ] Use static code analysis tools
- [ ] Implement automated security testing

## SDLC Integration
- [ ] Include security in design phase
- [ ] Conduct security-focused code reviews
- [ ] Perform security testing in CI/CD
- [ ] Establish vulnerability management process