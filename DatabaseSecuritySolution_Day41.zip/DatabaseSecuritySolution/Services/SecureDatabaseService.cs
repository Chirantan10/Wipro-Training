using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace DatabaseSecuritySolution.Services
{
    public class SecureDatabaseService
    {
        private readonly string _connectionString;
        private readonly DatabaseEncryptionService _encryptionService;

        public SecureDatabaseService(
            IConfiguration configuration, 
            DatabaseEncryptionService encryptionService)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
            _encryptionService = encryptionService;
        }

        public User GetUserById(int userId)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                // Parameterized query to prevent SQL injection
                string query = "SELECT Id, Name, Email, EncryptedCreditCard FROM Users WHERE Id = @UserId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@UserId", userId);
                
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                
                if (reader.Read())
                {
                    return new User
                    {
                        Id = reader.GetInt32(0),
                        Name = reader.GetString(1),
                        Email = reader.GetString(2),
                        // Credit card is stored encrypted and will be decrypted when needed
                        CreditCardNumber = _encryptionService.DecryptData(reader.GetString(3))
                    };
                }
                
                return null;
            }
        }

        public int CreateUser(User user)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                // Parameterized query with encrypted data
                string query = @"INSERT INTO Users (Name, Email, EncryptedCreditCard, PasswordHash) 
                                VALUES (@Name, @Email, @EncryptedCreditCard, @PasswordHash);
                                SELECT SCOPE_IDENTITY();";
                
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Name", user.Name);
                command.Parameters.AddWithValue("@Email", user.Email);
                command.Parameters.AddWithValue("@EncryptedCreditCard", 
                    _encryptionService.EncryptData(user.CreditCardNumber));
                command.Parameters.AddWithValue("@PasswordHash", 
                    _encryptionService.HashPassword(user.Password));
                
                connection.Open();
                var result = command.ExecuteScalar();
                return Convert.ToInt32(result);
            }
        }

        public bool ValidateUserCredentials(string email, string password)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                string query = "SELECT PasswordHash FROM Users WHERE Email = @Email";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Email", email);
                
                connection.Open();
                var result = command.ExecuteScalar();
                
                if (result != null)
                {
                    string storedHash = result.ToString();
                    return _encryptionService.VerifyPassword(password, storedHash);
                }
                
                return false;
            }
        }
    }
}